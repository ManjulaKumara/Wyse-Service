
<?php $__env->startSection('content'); ?>
<?php
    if (Request::segment(2)=='view'||Request::segment(2)=='edit') {
        $elements=DB::table('user_role_permissions')->join('modules','user_role_permissions.md_code','=','modules.md_code')
            ->select('user_role_permissions.*','modules.md_name as module_name','modules.can_create as can_createM','modules.can_read as can_readM','modules.can_update as can_updateM','modules.can_delete as can_deleteM')
            ->where('user_role_permissions.role_id',$user_role->id)
            ->get();
    } else {
        $elements =DB::table('modules')->where('md_code','<>','modules')->orderBy('id')->get();
    }

?>
<div class="card">
    <div class="card-header border-0 pt-6">
        <!--begin::Card title-->
        <div class="card-title">
            <h4><?php if(Request::segment(2)=='view'): ?> View <?php elseif(Request::segment(2)=='edit'): ?> Update <?php else: ?> New <?php endif; ?> User Role</h4>
        </div>
        <!--begin::Card title-->
        <!--begin::Card toolbar-->
        <div class="card-toolbar">
            <!--begin::Toolbar-->
            <div class="d-flex justify-content-end" data-kt-customer-table-toolbar="base">
                <!--begin::Add new-->
                <a href="<?php echo e(url('user-role/all')); ?>"><button type="button" class="btn btn-success" >Back<i class="fa fa-angle-left"></i></button></a>
                <!--end::Add new-->
            </div>
            <!--end::Toolbar-->
        </div>
        <!--end::Card toolbar-->
    </div>
    <form class="form" method="POST" <?php if(Request::segment(2)=='view'): ?> action="<?php echo e(url('#')); ?>" <?php elseif(Request::segment(2)=='edit'): ?> action="<?php echo e(url('/user-role/update/'.$user_role->id)); ?>" <?php else: ?> action="<?php echo e(url('user-role/store')); ?>" <?php endif; ?>>
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="form-group row">
                <div class="col-lg-6">
                    <label class="required">Role Code</label>
                    <input type="text"  id="role_code" name="role_code" class="form-control" required <?php if(Request::segment(2)=='view'): ?> value="<?php echo e($user_role->role_code); ?>" readonly <?php elseif(Request::segment(2)=='edit'): ?> value="<?php echo e($user_role->role_code); ?>" <?php else: ?> value="" <?php endif; ?>/>
                </div>
                <div class="col-lg-6">
                    <label class="required">User Role Name</label>
                    <input type="text" id="role_name" name="role_name" required class="form-control" <?php if(Request::segment(2)=='view'): ?> value="<?php echo e($user_role->role_name); ?>" readonly <?php elseif(Request::segment(2)=='edit'): ?> value="<?php echo e($user_role->role_name); ?>" <?php else: ?> value="" <?php endif; ?>/>
                    
                </div>
            </div><br>
            <div class="form-group row">
                <div class="col-lg-6">
                    <label class="required">Status</label>
                    <div class="radio-inline">
                        <label class="radio radio-solid">
                            <input type="radio" id="status" name="is_active" value="1" <?php if(Request::segment(2)=='view'): ?> disabled <?php if($user_role->is_active==1): ?> checked="checked" <?php endif; ?> <?php elseif(Request::segment(2)=='edit'): ?> <?php if($user_role->is_active==1): ?> checked="checked" <?php endif; ?> <?php else: ?>  checked="checked"  <?php endif; ?>/>
                            <span></span>
                            Active
                            </label>
                        <label class="radio radio-solid">
                            <input type="radio" id="status" name="is_active" value="0" <?php if(Request::segment(2)=='view'): ?> disabled <?php if($user_role->is_active==0): ?> checked="checked" <?php endif; ?> <?php elseif(Request::segment(2)=='edit'): ?> <?php if($user_role->is_active==0): ?> checked="checked" <?php endif; ?> <?php else: ?> value="" <?php endif; ?>/>
                            <span></span>
                            InActive
                        </label>
                    </div>
                    <span class="form-text text-muted">Please select status</span>
                </div>
            </div><br>
            <div class="separator separator-dashed my-5"></div>
            <div class="col-lg-12" >
                <table class="table" id="user_permission" style="overflow: scroll !important;display: block;">
                    <thead>
                        <tr>
                            <th scope="col">Module</th>
                            <th scope="col">Is Enable</th>
                            <th scope="col">Can Read</th>
                            <th scope="col">Can Create</th>
                            <th scope="col">Can Update</th>
                            <th scope="col">Can Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row" style="width: 30%">
                                    <?php if(Request::segment(2)=='view'||Request::segment(2)=='edit'): ?>
                                    <?php echo e($element->module_name); ?>

                                    <?php else: ?>
                                    <?php echo e($element->md_name); ?>

                                    <?php endif; ?>
                                    <input type="hidden" name="<?php echo e('element['.$element->id.'][0][]'); ?>" value="<?php echo e($element->md_code); ?>">
                                    <input type="hidden" name="<?php echo e('element['.$element->id.'][1][]'); ?>" value="<?php echo e($element->md_group); ?>">
                                </td>
                                <td>
                                    <span class="switch switch-sm switch-icon">
                                        <label>
                                            <input id="enable<?php echo e($element->id); ?>" name="<?php echo e('element['.$element->id.'][2][]'); ?>" type="checkbox"  <?php if(Request::segment(2)=='view'): ?> <?php if(isset($element)): ?>  <?php if($element->is_enable=='1'): ?> checked <?php endif; ?> <?php endif; ?> disabled <?php elseif(Request::segment(2)=='edit'): ?> <?php if(isset($element)): ?>  <?php if($element->is_enable=='1'): ?> checked <?php endif; ?> <?php endif; ?> <?php else: ?> <?php if(isset($element)): ?>  <?php if($element->is_active=='1'): ?> checked <?php endif; ?> <?php endif; ?> <?php endif; ?>/>
                                            <span></span>
                                        </label>
                                    </span>
                                </td>
                                <td>
                                    <span class="switch switch-sm switch-icon">
                                        <label>
                                            <input type="checkbox" id="read<?php echo e($element->id); ?>" name="<?php echo e('element['.$element->id.'][3][]'); ?>" <?php if(Request::segment(2)=='view'): ?> <?php if(isset($element)): ?> <?php if($element->can_readM=='off'): ?> disabled <?php endif; ?> <?php if($element->can_read=='1'): ?> checked <?php endif; ?> <?php endif; ?>  disabled <?php elseif(Request::segment(2)=='edit'): ?> <?php if(isset($element)): ?> <?php if($element->can_readM=='off'): ?> disabled <?php endif; ?> <?php if($element->can_read=='1'): ?> checked <?php endif; ?> <?php endif; ?> <?php else: ?> <?php if(isset($element)): ?>  <?php if($element->can_read=='off'): ?> disabled <?php endif; ?> <?php endif; ?> <?php endif; ?>/>
                                            <span></span>
                                        </label>
                                    </span>
                                </td>
                                <td>
                                    <span class="switch switch-sm switch-icon">
                                        <label>
                                            <input type="checkbox" id="create<?php echo e($element->id); ?>" name="<?php echo e('element['.$element->id.'][4][]'); ?>" <?php if(Request::segment(2)=='view'): ?> <?php if(isset($element)): ?> <?php if($element->can_createM=='off'): ?> disabled <?php endif; ?> <?php if($element->can_create=='1'): ?> checked <?php endif; ?> <?php endif; ?> disabled <?php elseif(Request::segment(2)=='edit'): ?> <?php if(isset($element)): ?> <?php if($element->can_createM=='off'): ?> disabled <?php endif; ?> <?php if($element->can_create=='1'): ?> checked <?php endif; ?> <?php endif; ?> <?php else: ?> <?php if(isset($element)): ?>  <?php if($element->can_create=='off'): ?> disabled <?php endif; ?> <?php endif; ?> <?php endif; ?>/>
                                            <span></span>
                                        </label>
                                    </span>
                                </td>
                                <td>
                                    <span class="switch switch-sm switch-icon">
                                        <label>
                                            <input type="checkbox" id="update<?php echo e($element->id); ?>" name="<?php echo e('element['.$element->id.'][5][]'); ?>" <?php if(Request::segment(2)=='view'): ?> <?php if(isset($element)): ?> <?php if($element->can_updateM=='off'): ?> disabled <?php endif; ?>  <?php if($element->can_update=='1'): ?> checked <?php endif; ?> <?php endif; ?> disabled <?php elseif(Request::segment(2)=='edit'): ?> <?php if(isset($element)): ?> <?php if($element->can_updateM=='off'): ?> disabled <?php endif; ?>  <?php if($element->can_update=='1'): ?> checked <?php endif; ?> <?php endif; ?> <?php else: ?> <?php if(isset($element)): ?>  <?php if($element->can_update=='off'): ?> disabled <?php endif; ?> <?php endif; ?> <?php endif; ?>/>
                                            <span></span>
                                        </label>
                                    </span>
                                </td>
                                <td>
                                    <span class="switch switch-sm switch-icon">
                                        <label>
                                            <input type="checkbox" id="delete<?php echo e($element->id); ?>" name="<?php echo e('element['.$element->id.'][6][]'); ?>" <?php if(Request::segment(2)=='view'): ?> <?php if(isset($element)): ?>  <?php if($element->can_deleteM=='off'): ?> disabled <?php endif; ?> <?php if($element->can_delete=='1'): ?> checked <?php endif; ?> <?php endif; ?> disabled <?php elseif(Request::segment(2)=='edit'): ?> <?php if(isset($element)): ?>  <?php if($element->can_deleteM=='off'): ?> disabled <?php endif; ?> <?php if($element->can_delete=='1'): ?> checked <?php endif; ?> <?php endif; ?> <?php else: ?> <?php if(isset($element)): ?>  <?php if($element->can_delete=='off'): ?> disabled <?php endif; ?> <?php endif; ?> <?php endif; ?>/>
                                            <span></span>
                                        </label>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="form-group row">
                <div class="col-lg-6"></div>
                <div class="col-lg-6" style="text-align-last: right" id="create_button">
                    <button type="reset" class="btn btn-secondary btn-lg mr-3" <?php if(Request::segment(2)=='view'): ?> disabled <?php endif; ?>>
                        <i class="fas fa-redo"></i> Reset
                    </button>
                    <button type="submit" class="btn btn-primary btn-lg mr-3" <?php if(Request::segment(2)=='view'): ?> disabled <?php endif; ?>>
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.wyse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\laravel\Wyse-Service\resources\views/pages/MasterFile/user_role/_form.blade.php ENDPATH**/ ?>