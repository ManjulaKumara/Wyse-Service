
<?php /**PATH D:\Projects\laravel\Wyse-Service\resources\views/dashboard.blade.php ENDPATH**/ ?>