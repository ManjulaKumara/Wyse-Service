
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header border-0 pt-6">
        <!--begin::Card title-->
        <div class="card-title">
            <h4><?php if(Request::segment(2)=='view'): ?> View <?php elseif(Request::segment(2)=='edit'): ?> Update <?php else: ?> New <?php endif; ?> User</h4>
        </div>
        <!--begin::Card title-->
        <!--begin::Card toolbar-->
        <div class="card-toolbar">
            <!--begin::Toolbar-->
            <div class="d-flex justify-content-end" data-kt-customer-table-toolbar="base">
                <!--begin::Add new-->
                <a href="<?php echo e(url('users/all')); ?>"><button type="button" class="btn btn-success" >Back<i class="fa fa-angle-left"></i></button></a>
                <!--end::Add new-->
            </div>
            <!--end::Toolbar-->
        </div>
        <!--end::Card toolbar-->
    </div>
    <form class="form" method="POST" <?php if(Request::segment(2)=='view'): ?> action="<?php echo e(url('#')); ?>" <?php elseif(Request::segment(2)=='edit'): ?> action="<?php echo e(url('/user/update/'.$user->id)); ?>" <?php else: ?> action="<?php echo e(url('/user/store')); ?>" <?php endif; ?>>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="lead_id" id="cust_lead_id">
        <div class="card-body">
            <div class="form-group row">
                <div class="col-lg-6">
                    <label class="required">Name</label>
                    <input type="text"  id="name" name="name" class="form-control" required <?php if(Request::segment(2)=='view'): ?> value="<?php echo e($user->name); ?>" readonly <?php elseif(Request::segment(2)=='edit'): ?> value="<?php echo e($user->name); ?>" <?php else: ?> value="" <?php endif; ?>/>
                </div>
                <div class="col-lg-6">
                    <label class="required">Email</label>
                    <input type="email" id="email" name="email" required class="form-control" <?php if(Request::segment(2)=='view'): ?> value="<?php echo e($user->email); ?>" readonly <?php elseif(Request::segment(2)=='edit'): ?> value="<?php echo e($user->email); ?>" <?php else: ?> value="" <?php endif; ?>/>
                    
                </div>
            </div><br>
            <div class="form-group row">
                <div class="col-lg-6">
                    <label class="required">Password</label>
                    <input type="password"  id="password" name="password" class="form-control" required <?php if(Request::segment(2)=='view'): ?> readonly <?php elseif(Request::segment(2)=='edit'): ?> value="" <?php else: ?> value="" <?php endif; ?>/>
                </div>
                <div class="col-lg-6">
                    <label class="required">Confirm Password</label>
                    <input type="password" id="com_password" name="com_password" required class="form-control" <?php if(Request::segment(2)=='view'): ?> readonly <?php elseif(Request::segment(2)=='edit'): ?> value=""  <?php else: ?> value="" <?php endif; ?>/>
                    
                </div>
            </div><br>
            <div class="form-group row">
                <div class="col-lg-6">
                    <label class="required">User Role</label>
                    <select class="form-control js-example-basic-single compulsory" id="user_role" name="user_role" required>
                        <?php $__currentLoopData = $user_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user_role->id); ?>" <?php if(Request::segment(2)=='view'): ?> disabled <?php if($user_role->id==$user->user_role): ?> selected <?php endif; ?> <?php elseif(Request::segment(2)=='edit'): ?> <?php if($user_role->id==$user->user_role): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($user_role->role_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-lg-6">
                    <label class="required">Status</label>
                    <div class="radio-inline">
                        <label class="radio radio-solid">
                            <input type="radio" id="status" name="is_active" value="1" <?php if(Request::segment(2)=='view'): ?> disabled <?php if($user->is_active==1): ?> checked="checked" <?php endif; ?> <?php elseif(Request::segment(2)=='edit'): ?> <?php if($user->is_active==1): ?> checked="checked" <?php endif; ?> <?php else: ?>  checked="checked"  <?php endif; ?>/>
                            <span></span>
                            Active
                            </label>
                        <label class="radio radio-solid">
                            <input type="radio" id="status" name="is_active" value="0" <?php if(Request::segment(2)=='view'): ?> disabled <?php if($user->is_active==0): ?> checked="checked" <?php endif; ?> <?php elseif(Request::segment(2)=='edit'): ?> <?php if($user->is_active==0): ?> checked="checked" <?php endif; ?> <?php else: ?> value="" <?php endif; ?>/>
                            <span></span>
                            InActive
                        </label>
                    </div>
                    <span class="form-text text-muted">Please select status</span>
                </div>
            </div><br>
            <div class="form-group row">
                <div class="col-lg-6"></div>
                <div class="col-lg-6" style="text-align-last: right" >
                    <button type="reset" class="btn btn-secondary btn-lg mr-3" <?php if(Request::segment(2)=='view'): ?> disabled <?php endif; ?>>
                        <i class="fas fa-redo"></i> Reset
                    </button>
                    <button type="submit" class="btn btn-primary btn-lg mr-3" <?php if(Request::segment(2)=='view'): ?> disabled <?php endif; ?>>
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.wyse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\laravel\Wyse-Service\resources\views/pages/MasterFile/users/_form.blade.php ENDPATH**/ ?>