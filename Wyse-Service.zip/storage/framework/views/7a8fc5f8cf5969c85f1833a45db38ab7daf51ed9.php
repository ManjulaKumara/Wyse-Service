<?php $__env->startSection('optional_css'); ?>
<link href="<?php echo e(url('assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('/expense/store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
<div class="d-flex flex-column flex-lg-row">
    <!--begin::Content-->
    <div class="flex-lg-row-fluid mb-10 mb-lg-0 me-lg-7 me-xl-10">
        <div class="card">
            <!--begin::Card body-->
            <div class="card-body p-12">
                <div class="row">
                    <div class="col-md-6">
                        <h3>Expenses</h3>
                    </div>
                    <div class="col-md-6">
                        <h3 style="text-align: right">Date : <?php echo e($today); ?></h3>
                    </div>
                </div>
                <div class="separator separator-dashed my-10"></div>
                <!--begin::Form-->
                
                    <div class="mb-0">
                        <div class="row">
                            <div class="col-md-12">
                                <!--end::Top-->

                                <div class="row gx-10 mb-5">

                                    <!--begin::Col-->
                                    <div class="col-lg-6">
                                        <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Expense Name</label>
                                        <!--begin::Input group-->
                                        <div class="mb-5">
                                            <input type="text" id="expense_name" name="expense_name" required class="form-control form-control" />
                                        </div>
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Col-->
                                    <div class="col-lg-4">
                                        <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Amount</label>
                                        <!--begin::Input group-->
                                        <div class="mb-5">
                                            <input type="text" id="expense_amount" name="expense_amount" required class="form-control form-control" />
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <button type="submit" style="margin-top:25px;" class="btn btn-success">SAVE</button>
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <!--end::Table-->
                            </div>
                        </div>

                
            </div>
            <!--end::Card body-->
        </div>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('opyional_js'); ?>
<script src="<?php echo e(url('assets/plugins/global/plugins.bundle.js')); ?>"></script>
<script>
    $(document).on('select2:open', () => {
        document.querySelector('.select2-search__field').focus();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.wyse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\laravel\Wyse-Service\resources\views/pages/expenses/expenses.blade.php ENDPATH**/ ?>